﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace SnippetManager
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            Window1 window = new Window1();

            foreach (string filename in e.Args)
            {
                if (filename == "/?")
                {
                    MessageBox.Show("SnippetManager.exe [/notontop] [file1] [file2] [etc]\n\n"
                    + "where files are ASCII files, snippets are separated by a line of\n"
                    + "///////////////////////////////", "Usage");
                    return;
                }
                else if (filename == "/notontop")
                {
                    window.TopmostCheckbox.IsChecked = false;
                    
                }
                else
                {
                    window.LoadFile(filename);
                }
            }

            window.Show();
        }
    }
}
